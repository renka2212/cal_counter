from django.urls import path
from . import views

urlpatterns = [
    path('add_food/', views.add_food, name='add_food'),
    path('add_workout/', views.add_workout, name='add_workout'),
    path('summary/', views.summary, name='summary'),
]
