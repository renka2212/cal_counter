from django.contrib import admin
from .models import Food, Workout

admin.site.register(Food)
admin.site.register(Workout)
