from django.shortcuts import render, redirect
from .models import Food, Workout
from .forms import FoodForm, WorkoutForm

def add_food(request):
    if request.method == 'POST':
        form = FoodForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('summary')
    else:
        form = FoodForm()
    return render(request, 'tracker/add_food.html', {'form': form})

def add_workout(request):
    if request.method == 'POST':
        form = WorkoutForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('summary')
    else:
        form = WorkoutForm()
    return render(request, 'tracker/add_workout.html', {'form': form})

def summary(request):
    total_calories_consumed = sum(food.calories for food in Food.objects.all())
    total_calories_burned = sum(workout.calories_burned for workout in Workout.objects.all())
    net_calories = total_calories_consumed - total_calories_burned
    return render(request, 'tracker/summary.html', {
        'total_calories_consumed': total_calories_consumed,
        'total_calories_burned': total_calories_burned,
        'net_calories': net_calories
    })
