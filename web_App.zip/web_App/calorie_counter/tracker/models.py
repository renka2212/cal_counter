
from django.db import models

class Food(models.Model):
    name = models.CharField(max_length=100)
    calories = models.PositiveIntegerField()

    def __str__(self):
        return f"{self.name} ({self.calories} калорий)"

class Workout(models.Model):
    workout_type = models.CharField(max_length=100)
    calories_burned = models.PositiveIntegerField()

    def __str__(self):
        return f"{self.workout_type} ({self.calories_burned} калорий)"

