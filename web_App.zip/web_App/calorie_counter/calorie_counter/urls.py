from django.contrib import admin
from django.urls import path, include
from tracker import views  # Импортируем представления приложения tracker

urlpatterns = [
    path('admin/', admin.site.urls),
    path('tracker/', include('tracker.urls')),
    path('', views.summary, name='home'),  # Добавляем корневой маршрут
]
